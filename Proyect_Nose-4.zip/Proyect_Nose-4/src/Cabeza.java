public class Cabeza {

    boolean Mostrar_Cabeza = true;

    public Cabeza(boolean mostrar_Cabeza) {
        Mostrar_Cabeza = mostrar_Cabeza;
    }

    public boolean isMostrar_Cabeza() {
        return Mostrar_Cabeza;
    }

    public void setMostrar_Cabeza(boolean mostrar_Cabeza) {
        Mostrar_Cabeza = mostrar_Cabeza;
    }
}
